from typing import Callable
import pygame

class Context:
    """Represents a place you can be inside of, within the application, e.g. a
    menu or the core gameplay loop. Contexts can be told to "process" and they
    can be told to "render." Think of contexts like layers in an image editor,
    with only the topmost layer being allowed to "do things" but other layers
    still being visible (i.e. rendered) unless covered up by an opaque layer.

    Contexts can stack, with the application running the topmost context's
    `process` on every tick. Non-topmost contexts can still render unless they
    are covered by an "opaque" context."""

    class DelayedFunctor:
        """Represents a handler that has been queued to run after a time delay
        measured in seconds. Time only passes while the context is processing,
        and is advanced by the base Context class's `process` implementation."""
        def __init__(self, cb:Callable, delay:float):
            self.callback : Callable = cb
            self.delay    : float    = delay

    def __init__(self):

        # Control whether contexts below this one render their contents. Useful
        # for contexts that are meant to serve as overlays, e.g. menus with a
        # transparent or semitranslucent background.
        self.is_opaque : bool = False

        # Specify whether this context is a menu. Affects input processing.
        self.is_menu : bool = False

        # Support infrastructure for `Context._run_after`.
        self._delayed_functors : list[Context.DelayedFunctor] = []

    def process(self, time_delta:float):
        """Called if the context is topmost. A context should override this
        function with a handler which simulates the context forward, e.g. by
        handling user inputs, advancing any animations the context wishes to
        play, and so on.

        The `time_delta` parameter is the amount of time, measured in seconds,
        by which the context should advance forward.

        Overrides MUST call super."""
        for df in self._delayed_functors:
            df.delay -= time_delta
            if df.delay <= 0:
                df.callback()
        self._delayed_functors = [e for e in self._delayed_functors if e.delay > 0]

    def _run_after(self, callback:Callable, seconds:float):
        """Helper function for contexts: queue a callback to run after a given
        delay in seconds. For the purposes of these delays, time only passes
        while the context is the current context (i.e. while its `process`
        handler is being called)."""
        self._delayed_functors.append(
            Context.DelayedFunctor(callback, seconds)
        )

    def render(self, surface:pygame.Surface):
        """A context should override this function with a handler that will
        render to the provided surface. Overrides are encouraged to call super
        in case any superclass behaviors need to be added down the line."""
        pass
