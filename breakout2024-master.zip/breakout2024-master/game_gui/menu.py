"""Helper classes for building a GUI."""

from enum import Enum
from typing import Optional, Self
import pygame
from pygame import Surface
#
from geom import Vec2
from input_manager import ButtonState, INPUT_MANAGER

class Direction(Enum):
    UP    = 0
    RIGHT = 1
    DOWN  = 2
    LEFT  = 3

class Widget:
    """Base class for GUI widgets. Subclass this and override the methods that
    are documented as being overrideable.

    Among other things, widgets have a bounding box used for mouse hit tests,
    and the ability to influence keyboard navigation by setting the destination
    widget for each cardinal direction (up/down/left/right). If the user tries
    to navigate in a direction and the currently focused widget doesn't specify
    a destination for that direction, then we check its parent and ancestor
    widgets and honor the first destination we see."""
    def __init__(self):
        self.parent   : Optional[Self, "Menu"] = None
        self.children : list[Self]             = []

        self.focusable : bool = False

        # A widget's `pos` is its position offset relative to that of its parent
        self.pos    : Vec2 = Vec2()
        self.bounds : Vec2 = Vec2() # AABB size, with `pos` as top-left

        # Targets for directional keyboard navigation.
        self.navigation_target_up    : Optional[Self] = None
        self.navigation_target_down  : Optional[Self] = None
        self.navigation_target_right : Optional[Self] = None
        self.navigation_target_left  : Optional[Self] = None

        # State:
        self._last_focused_descendant : Optional[Self] = None

    @property
    def absolute_position(self) -> Vec2:
        """Return the widget's absolute position, i.e. not relative to its
        parent/ancestors."""
        if self.parent is None or isinstance(self.parent, Menu):
            return self.pos.clone()
        return self.pos + self.parent.absolute_position

    @property
    def bounds_center(self) -> Vec2:
        return self.pos + self.bounds / 2

    @property
    def menu(self) -> Optional["Menu"]:
        """Get the widget's containing menu."""
        if isinstance(self.parent, Menu):
            return self.parent
        if self.parent is None:
            return None
        return self.parent.menu

    def append_child(self, widget:Self):
        assert widget is not self

        if widget is self:
            return
        if widget.parent is self:
            return
        if widget.parent is not None:
            widget.parent.remove_child(widget)
        widget.parent = self
        self.children.append(widget)

    def contains_descendant(self, widget:Self) -> bool:
        """Returns true if `widget` is a child or descendant of this widget."""
        parent = widget.parent
        while isinstance(parent, Widget):
            if parent is self:
                return True
            parent = parent.parent
        return False

    def remove_child(self, widget:Self):
        assert widget is not self
        assert widget.parent is self
        assert widget in self.children

        if widget.parent is not self:
            return
        widget.parent = None
        self.children.remove(widget)

        last_focus = self._last_focused_descendant
        if last_focus is not None:
            if last_focus is widget or widget.contains_descendant(last_focus):
                self._last_focused_descendant = None

                parent = self.parent
                while isinstance(parent, Widget):
                    if parent._last_focused_descendant is widget:
                        parent._last_focused_descendant = None
                    parent = parent.parent

    def get_navigation_target(self, direction:Direction) -> Optional["Widget"]:
        """If this widget wants keyboard navigation in a given direction to move
        to a given other widget, then this method will return that widget."""
        match direction:
            case Direction.UP:
                return self.navigation_target_up
            case Direction.DOWN:
                return self.navigation_target_down
            case Direction.LEFT:
                return self.navigation_target_left
            case Direction.RIGHT:
                return self.navigation_target_right
        return None

    def set_navigation_target(self, direction:Direction, widget:Self):
        """Set whether this widget wants keyboard navigation in a given
        direction to move directly to a given other widget."""
        #
        # TODO: We'd benefit from being able to set non-Widget-type sentinel
        #       values for e.g. first-sibling, previous-sibling, next-sibling,
        #       and last-sibling. If we add that functionality, then we'll need
        #       to update `Menu`'s keynav code to honor it.
        #
        match direction:
            case Direction.UP:
                self.navigation_target_up = widget
            case Direction.DOWN:
                self.navigation_target_down = widget
            case Direction.LEFT:
                self.navigation_target_left = widget
            case Direction.RIGHT:
                self.navigation_target_right = widget

    def focus_would_be_routed_to(self) -> Optional["Widget"]:
        """Returns the widget that focus would be routed to, were a menu to
        attempt to focus this widget. In general, if something (e.g. keyboard
        navigation targets) tries to route focus to a non-focusable widget, then
        we will focus its first focusable descendant initially; after that, we
        try to remember its last focused focusable descendant and prefer to
        route focus back to that.

        (Why bother remembering the last focused descendant? Imagine you have
        two vertical menus side by side, and you want the user to be able to
        navigate between the menus using the left or right arrow keys. The menu
        items are focusable but the menus themselves are not. If you set the
        lefthand menu's righthand navigation target to the righthand menu, and
        vice versa, then "remembering the last focused descendant" means that
        when the user switches back and forth between the menus, they don't lose
        their place *within* the menus.)"""

        if self.focusable:
            return self

        target = self._last_focused_descendant
        if target is not None and target.focusable:
            return target

        for child in self.children:
            target = child.focus_would_be_routed_to()
            if target is not None:
                return target

        return None

    #
    # Methods below should be overridden by subclasses.
    #

    def draw(self) -> Optional[Surface]:
        """Override this function as appropriate. Return a Surface containing
        the content of your widget, or return None to avoid drawing anything."""
        return None

    def on_activated(self) -> bool:
        """Override this function as appropriate. Return `True` to signal that
        you've consumed the "activate" button press."""
        return False

    def on_cancel(self) -> bool:
        """Override this function as appropriate. Return `True` to signal that
        you've consumed the "cancel" button press."""
        return False

    def on_mouseover(self) -> None:
        """Override this function as appropriate."""
        pass

    def on_mouseout(self) -> None:
        """Override this function as appropriate."""
        pass

    def on_mousedown(self, buttons) -> None:
        """Override this function as appropriate."""
        pass

    def on_nav_focus_gained(self) -> None:
        """Override this function as appropriate. Make sure to call super."""
        parent = self.parent
        while isinstance(parent, Widget):
            parent._last_focused_descendant = self
            parent = parent.parent

    def on_nav_focus_lost(self) -> None:
        """Override this function as appropriate."""
        pass

class Menu:
    """Manages state for a menu, e.g. keeping track of which widget has focus
    and handling keyboard navigation."""
    #
    # TODO: `Menu.close()` implementation
    # TODO: Mouse click handling (needs INPUT_MANAGER help; see comments below)
    #

    def __init__(self):
        self.root = Widget()

        # Control whether the Escape key, or the gamepad B button, etc., can
        # close this menu (if not handled by a focused widget).
        self.allow_backing_out : bool = True

        # State vars below.

        self.current_keynav_target : Optional[Widget] = None
        self.default_keynav_target : Optional[Widget] = None

        self.last_mouseover_target : Optional[Widget] = None

    def on_opened(self):
        """This should be called when the menu is opened."""
        initial_target = self.default_keynav_target or self.children[0]
        if initial_target:
            self.set_current_keynav_target(initial_target)

        self.last_mouseover_target = None

    def close(self):
        #
        # TODO: Menu should probably be a subclass of Context, in which case it
        #       would then be able to remove itself from CONTEXT_MANAGER.
        #
        pass

    def focusable_widget_at_point(self, x:int, y:int) -> Optional[Widget]:
        """Identify the focusable widget at the given point. Descendant widgets
        have preference over ancestors; next-sibling widgets have preference
        over previous-sibling widgets."""
        if self.root is None:
            return None

        result : Optional[Widget] = None
        #
        def _process(current:Widget, basis:Vec2):
            nonlocal result

            this_pos = current.pos + basis
            if current.focusable:
                rx = x - this_pos.x
                ry = y - this_pos.y
                if 0 <= rx <= current.bounds.x and 0 <= ry <= current.bounds.y:
                    result = current

            for child in current.children:
                _process(child, this_pos)

        _process(self.root, Vec2(0, 0))
        return result

    def _set_current_keynav_target_direct(self, widget:Widget):
        """Set the current keyboard navigation target DIRECTLY to `widget`,
        failing if the target widget is not focusable."""
        if not widget.focusable:
            return
        if self.current_keynav_target is widget:
            return
        if self.current_keynav_target is not None:
            self.current_keynav_target.on_nav_focus_lost()
        self.current_keynav_target = widget
        widget.on_nav_focus_gained()

    def set_current_keynav_target(self, widget:Widget) -> bool:
        """Set the current keyboard navigation target to `widget` or, if it's
        not focusable, to the best-applicable focusable descendant. Returns
        True if any change occurs."""
        if widget.focusable:
            self._set_current_keynav_target_direct(widget)
            return False
        widget = widget.focus_would_be_routed_to()
        if widget is None:
            return False
        self._set_current_keynav_target_direct(widget)
        return True

    def _handle_keyboard_navigation(self, direction:Direction) -> bool:
        """Attempt to keyboard-navigate in a given direction, and return True if
        there's anything to navigate to (and, by implication, if navigation in
        that direction succeeds)."""
        def _search(widget:Widget) -> bool:
            target = widget.get_navigation_target(direction)
            if target:
                if self.set_current_keynav_target(target):
                    return True

            target = target.parent
            if isinstance(target, Widget):
                return _search(target)

            return False

        return _search(self.current_keynav_target)

    def update(self):
        input_state = INPUT_MANAGER.state

        def _dispatch_event(target, handler_name):
            handled = getattr(target, handler_name)()
            while not handled:
                target = target.parent
                if not isinstance(target, Widget):
                    return False
                handled = getattr(target, handler_name)()
            return True

        if self.current_keynav_target is not None:
            if input_state.ui_activate == ButtonState.DOWN:
                _dispatch_event(self.current_keynav_target, "on_activate")

            if input_state.ui_cancel == ButtonState.DOWN:
                if not _dispatch_event(self.current_keynav_target, "on_activate"):
                    if self.allow_backing_out:
                        self.close()
                        return

            #
            # Handle keyboard navigation.
            #
            DOWN_OR_REPEAT = (ButtonState.DOWN, ButtonState.AUTO_REPEAT)
            done = False
            if input_state.ui_navigate_up in DOWN_OR_REPEAT:
                done = self._handle_keyboard_navigation(Direction.UP)
            if (not done) and input_state.ui_navigate_down in DOWN_OR_REPEAT:
                done = self._handle_keyboard_navigation(Direction.DOWN)
            if (not done) and input_state.ui_navigate_left in DOWN_OR_REPEAT:
                done = self._handle_keyboard_navigation(Direction.LEFT)
            if (not done) and input_state.ui_navigate_right in DOWN_OR_REPEAT:
                done = self._handle_keyboard_navigation(Direction.RIGHT)

        def _clear_last_mouseover():
            if self.last_mouseover_target is not None:
                self.last_mouseover_target.on_mouseout()
                self.last_mouseover_target = None

        display = pygame.display.get_surface()
        disp_w  = display.get_width()
        disp_h  = display.get_height()
        if display is not None:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if not (0 <= mouse_x <= disp_w and 0 <= mouse_y <= disp_h):
                _clear_last_mouseover()
            else:
                #
                # Mouse is in bounds. What's underneath it?
                #
                new_target = self.focusable_widget_at_point(mouse_x, mouse_y)
                #
                # BTW, a nice benefit of redoing the raycast every time is that
                # if widgets move or their `focusable` flags change, we just
                # naturally handle that as part of the same process as dealing
                # with the mouse itself moving within our window.
                #
                if new_target != self.last_mouseover_target:
                    _clear_last_mouseover()
                    if new_target is not None:
                        new_target.on_mouseover()
                        self.last_mouseover_target = new_target
                if new_target is not None:
                    #
                    # If the mouse is down, handle it.
                    #
                    # TODO: This will fire for each frame that the mouse is down
                    #       for, but what we want is to only fire on the first
                    #       frame for which the mouse is down. We'll probably
                    #       have to add some mouse-related helpers to the core
                    #       input manager and then rely on that.
                    #
                    buttons    = pygame.mouse.get_pressed()
                    any_button = False
                    for button in buttons:
                        if button:
                            any_button = True
                            break
                    if any_button:
                        new_target.on_mousedown(buttons)
        else:
            #
            # We don't have a window to render to.
            #
            _clear_last_mouseover()

    def render(self, destination_surface:Surface):
        def _per_widget(widget:Widget, basis:Vec2):
            nonlocal parent_pos

            surface  = widget.render()
            this_pos = widget.pos + basis
            if surface is not None:
                destination_surface.blit(surface, (this_pos.x, this_pos.y))

            for child in widget.children:
                _per_widget(child, this_pos)

        _per_widget(self.root, Vec2(0, 0))
