from enum import Enum
import math
from typing import Optional
#
from pygame import Color, Rect, Surface
from pygame.freetype import Font

class TextAlign(Enum):
    LEFT   = 0
    CENTER = 1
    RIGHT  = 2

class FontStamp:
    """Given a font, a string, and settings like text alignment, this class can
    be used to compute word-wrapping. Once computed, it can be "stamped" onto a
    surface to draw text, optionally with additional effects like a padded
    background."""

    class _Word:
        def __init__(self):
            self.word : str   = ""
            self.x    : int = 0
            self.y    : int = 0
            self.rect : Optional[Rect] = None

        @property
        def bottom(self) -> int:
            if self.rect is None:
                return 0
            return self.y + self.rect.y + self.rect.height

        @property
        def left(self) -> int:
            if self.rect is None:
                return self.x
            return self.x + self.rect.x

        @property
        def right(self) -> int:
            if self.rect is None:
                return 0
            return self.left + self.rect.width

    def __init__(self, font:Font, text:str):
        self.font : Font = font
        self.text : str  = text

        # Rendering options
        self.back_color : Optional[Color] = None
        self.text_color : Color           = (0,0,0)
        self.max_width  : float           = math.inf
        self.padding    : int             = 0
        self.text_align : TextAlign       = TextAlign.LEFT

        # Computed state to render
        self.words : list[FontStamp._Word] = []

    @property
    def width(self) -> int:
        if len(self.words) == 0:
            return 0
        return self.words[-1].right - self.words[0].left

    @property
    def height(self) -> int:
        if len(self.words) == 0:
            return 0
        return self.words[-1].bottom

    def compute(self):
        self.words = []

        words        = self.text.split(' ')
        space_rect   = self.font.get_rect(' ')
        line_spacing = self.font.get_sized_height() + 2

        x    : int = 0
        y    : int = 0
        line : list[FontStamp._Word] = []

        def _align_line():
            nonlocal line

            if len(line) == 0:
                return
            line_width = line[-1].right - line[0].left

            offset_x = 0
            if self.text_align == TextAlign.CENTER:
                offset_x  = (self.max_width - line_width) / 2
                offset_x -= line[0].left
            elif self.text_align == TextAlign.RIGHT:
                offset_x = self.max_width - line_width

            if offset_x > 0:
                for item in line:
                    item.x += offset_x

        def _to_next_line():
            nonlocal line, x, y

            if len(line) == 0:
                x  = 0
                y += line_spacing
                return

            _align_line()

            self.words += line
            line = []
            x    = 0
            y   += line_spacing

        for word in words:
            bounds = self.font.get_rect(word)

            to_render = FontStamp._Word()
            to_render.word = word
            to_render.rect = bounds

            if bounds.width >= self.max_width: # word must go on its own line
                if len(line) > 0:
                    _to_next_line()
                else:
                    x = 0
                to_render.x = x
                to_render.y = y
                line.append(to_render)
                _to_next_line()
                continue

            if x + bounds.x + bounds.width >= self.max_width: # word would wrap
                _to_next_line()
            elif len(line) > 0:
                x += space_rect.width

            to_render.x = x
            to_render.y = y
            line.append(to_render)
            x += bounds.width
            x += bounds.x # needed; some words may have insets or, more pertinently, outsets

        if len(line) > 0:
            _align_line()
            self.words += line

    def draw(self, surface:Surface, x:float, y:float):

        if self.back_color is not None:
            #
            # Render the background, including padding and the spaces between
            # each word. We want to render the entire background first so that
            # if the padding size is larger than the width of a space, the
            # padding for a later word won't cover up the text of an earlier
            # word.
            #
            is_first_word_of_line : bool = True
            for i in range(len(self.words)):
                word = self.words[i]

                if self.padding > 0:
                    rect = word.rect.copy()
                    rect.x = x + word.x + rect.x
                    rect.y = y + word.y
                    rect.inflate_ip(self.padding, self.padding)
                    surface.fill(self.back_color, rect)

                if i > 0:
                    if word.y > self.words[i - 1].y:
                        is_first_word_of_line = True
                #
                if not is_first_word_of_line:
                    #
                    # Fill the spaces between words.
                    #
                    prev = self.words[i - 1]
                    rect = Rect(prev.right, word.y, word.left - prev.right, prev.rect.height)
                    rect.move_ip(x, y)
                    if self.padding > 0:
                        rect.inflate_ip(self.padding, self.padding)
                    surface.fill(self.back_color, rect)
                #
                is_first_word_of_line = False

        for word in self.words:
            word_x = word.left + x
            word_y = word.y    + y

            self.font.render_to(
                surface,
                (word_x, word_y),
                word.word,
                fgcolor=self.text_color,
                bgcolor=self.back_color
            )
