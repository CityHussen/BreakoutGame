from enum import Enum
import pygame
from geom import Vec2

class Block:
    class Type(Enum):
        A = 1,
        B = 2,
        C = 3,
        D = 4

    TYPES = [Type.A, Type.B, Type.C, Type.D]

    IMAGE_TYPE_A = pygame.image.load("assets/block_yellow.png")
    IMAGE_TYPE_B = pygame.image.load("assets/block_green.png")
    IMAGE_TYPE_C = pygame.image.load("assets/block_orange.png")
    IMAGE_TYPE_D = pygame.image.load("assets/block_red.png")

    # TODO: Convert these to game settings loaded from a config file.
    type_a_score : int = 1
    type_b_score : int = 3
    type_c_score : int = 5
    type_d_score : int = 7

    SIZE : Vec2 = Vec2(IMAGE_TYPE_A.get_width(), IMAGE_TYPE_A.get_height())

    def __init__(self):
        self.type : Block.Type = Block.Type.A
        self.pos  : Vec2       = Vec2() # top-left corner

    @property
    def center(self) -> Vec2:
        return self.pos + Block.SIZE / 2

    @property
    def score(self) -> int:
        match self.type:
            case Block.Type.A:
                return Block.type_a_score
            case Block.Type.B:
                return Block.type_b_score
            case Block.Type.C:
                return Block.type_c_score
            case Block.Type.D:
                return Block.type_d_score
        return 0

    @property
    def size(self) -> Vec2:
        return Block.SIZE

    def draw(self, surface : pygame.Surface):
        image : pygame.Surface = Block.IMAGE_TYPE_A
        match self.type:
            case Block.Type.A:
                image = Block.IMAGE_TYPE_A
            case Block.Type.B:
                image = Block.IMAGE_TYPE_B
            case Block.Type.C:
                image = Block.IMAGE_TYPE_C
            case Block.Type.D:
                image = Block.IMAGE_TYPE_D
        surface.blit(image, self.pos.tuple())
