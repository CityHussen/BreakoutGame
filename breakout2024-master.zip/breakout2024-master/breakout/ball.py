from math import radians
from typing import Optional, Tuple
import pygame
from geom import BoxSide, Vec2
from geom import line_line_intersection, ray_hits_aabb
from .paddle import Paddle
from .playing_field_metrics import BOARD_METRICS

class Ball:
    # TODO: Convert these to game settings loaded from a config file.
    minimum_angle       : float = radians(5)
    angle_skew_by_speed : float = 0
    #
    initial_speed       : float = 0.20 * BOARD_METRICS.HEIGHT # speed per second
    speed_increase_a    : float = 0.25 * BOARD_METRICS.HEIGHT
    speed_increase_b    : float = 0.30 * BOARD_METRICS.HEIGHT
    speed_increase_c    : float = 0.35 * BOARD_METRICS.HEIGHT

    IMAGE  : pygame.Surface = pygame.image.load("assets/ball.png")
    RADIUS : float          = IMAGE.get_width() / 2

    def __init__(self):
        self.pos            : Vec2 = Vec2() # centerpoint
        self.is_active      : bool = False
        self.is_destructive : bool = False
        self.is_destroyed   : bool = False # ball fell out of bounds?
        self.velocity       : Vec2 = Vec2() # speed per second

    @property
    def speed(self) -> float:
        return self.velocity.length()
    #
    @speed.setter
    def speed(self, desired:float):
        self.velocity.normalize().scale(desired)

    def draw(self, surface : pygame.Surface):
        surface.blit(Ball.IMAGE, (self.pos - Ball.RADIUS).tuple())

    def compute_paddle_bounce_angle(self, paddle:Paddle, impact_point:Vec2):
        """This function should be invoked while resolving a ball/paddle
        collision, after the ball's position has been corrected to no longer
        intersect with the paddle but before the ball's movement away from the
        paddle is simulated.

        The `impact_point` should be the point along the paddle's top edge at
        which the ball is known to have collided with the paddle. Correction
        of the ball's position should've placed it such that this point lies
        on the ball's edge."""

        paddle_percent : float = (impact_point - paddle.pos).x / paddle.width

        outbound_angle : float = radians(22.5)
        if paddle_percent < 0.25 or paddle_percent > 0.75:
            outbound_angle = radians(45)

        influence_by_speed : float = Ball.angle_skew_by_speed * self.speed
        outbound_angle -= influence_by_speed

        UP_ANGLE = radians(90)

        def is_too_cardinal(angle:float) -> bool:
            # https://stackoverflow.com/a/20152597
            CYCLE = 90
            RANGE = Ball.minimum_angle
            remainder = angle % CYCLE
            return remainder <= RANGE or CYCLE - remainder <= RANGE

        if paddle_percent < 0.5: # leftward
            outbound_angle += UP_ANGLE

            if is_too_cardinal(outbound_angle) or outbound_angle < UP_ANGLE:
                #
                # Ensure that we don't angle the ball in a cardinal direction,
                # and ensure we don't accidentally flip its movement rightward
                # by applying the speed skew.
                #
                outbound_angle = UP_ANGLE + Ball.minimum_angle
        else: # rightward
            outbound_angle = UP_ANGLE - outbound_angle

            if is_too_cardinal(outbound_angle) or outbound_angle > UP_ANGLE:
                #
                # Ensure that we don't angle the ball in a cardinal direction,
                # and ensure we don't accidentally flip its movement leftward
                # by applying the speed skew.
                #
                outbound_angle = UP_ANGLE - Ball.minimum_angle

        self.velocity.set_angle(outbound_angle)

        # In trig, positive-Y points up; in computers, down.
        self.velocity.y = -self.velocity.y
