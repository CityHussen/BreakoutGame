"""Defines size and position information for the playing field."""

from enum import Enum
from .block import Block
from geom import Vec2

class ScreenEdge(Enum):
    TOP    = 0
    LEFT   = 1
    RIGHT  = 2
    BOTTOM = 3

    BACKWALL = TOP
    PIT      = BOTTOM

class BLOCK_GRID:
    """Metrics for the grid of blocks spawned during play."""
    GAP_BETWEEN_BLOCKS  = 4
    ROWS_PER_BLOCK_TYPE = 2
    Y_OFFSET            = 64 # Y-position of topmost blocks

    BLOCKS_PER_ROW    = 14
    BLOCKS_PER_COLUMN = ROWS_PER_BLOCK_TYPE * len(Block.TYPES)

    WIDTH  = (BLOCKS_PER_ROW    - 1) * GAP_BETWEEN_BLOCKS + (BLOCKS_PER_ROW    * Block.SIZE.x)
    HEIGHT = (BLOCKS_PER_COLUMN - 1) * GAP_BETWEEN_BLOCKS + (BLOCKS_PER_COLUMN * Block.SIZE.y)

    CENTER = Vec2(WIDTH / 2, HEIGHT / 2 + Y_OFFSET)

class BOARD_METRICS:
    """Metrics for the playing field as a whole."""
    WIDTH  = BLOCK_GRID.WIDTH
    HEIGHT = WIDTH * 1.3

    SIZE   = Vec2(WIDTH, HEIGHT)
    CENTER = SIZE / 2
