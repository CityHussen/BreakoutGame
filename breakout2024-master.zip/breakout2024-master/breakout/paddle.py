from dataclasses import dataclass
from typing import Optional
import pygame
from geom import Vec2
from .playing_field_metrics import BOARD_METRICS

class Paddle:
    @dataclass
    class XConstraint:
        minimum : float = 0.0
        maximum : float = 100.0

    IMAGE_LEFT   : Optional[pygame.Surface] = pygame.image.load("assets/paddle_edge.png")
    IMAGE_RIGHT  : Optional[pygame.Surface] = pygame.transform.flip(IMAGE_LEFT, True, False)
    IMAGE_MIDDLE : Optional[pygame.Surface] = pygame.image.load("assets/paddle_middle.png")

    # TODO: Convert these to game settings loaded from a config file.
    default_width  : float = 0.15 * BOARD_METRICS.WIDTH
    narrowed_width : float = default_width / 2
    maximum_speed  : float = 0.25 * BOARD_METRICS.HEIGHT # speed per second

    def __init__(self):
        self.pos   : Vec2  = Vec2() # top-left corner
        self.width : float = Paddle.default_width

        self.constrain_x = Paddle.XConstraint(0, 100)

        self.image : Optional[pygame.Surface] = None

    @property
    def center(self) -> Vec2:
        return self.pos + self.size / 2

    @property
    def size(self) -> Vec2:
        return Vec2(self.width, Paddle.IMAGE_MIDDLE.get_height())

    def _rebuild_image(self):
        """Build and cache an image for the whole paddle, given its current
        width. Blitting the entire paddle to the screen will be more performant
        than blitting each piece, each time, each frame."""
        endcap_width = Paddle.IMAGE_LEFT.get_width()
        inner_width  = int(self.width - endcap_width * 2)
        height       = Paddle.IMAGE_MIDDLE.get_height()

        self.image = pygame.Surface((self.width, height))
        self.image.blit(Paddle.IMAGE_LEFT, (0, 0))
        self.image.blit(
            Paddle.IMAGE_RIGHT,
            (self.width - endcap_width, 0)
        )

        for x in range(0, inner_width, Paddle.IMAGE_MIDDLE.get_width()):
            self.image.blit(Paddle.IMAGE_MIDDLE, (endcap_width + x, 0))

    def draw(self, surface : pygame.Surface):
        if self.image is None:
            self._rebuild_image()
        surface.blit(self.image, self.pos.tuple())

    def attempt_horizontal_move(self, by:float):
        """Try to move the paddle horizontally, honoring the X-constraint."""
        self.pos.x += by

        self.pos.x = max(self.pos.x, self.constrain_x.minimum)
        self.pos.x = min(self.pos.x, self.constrain_x.maximum - self.width)

    def set_width(self, desired:float):
        """Change the paddle's width, keeping its position fixed at its
        centerpoint."""
        assert desired >= 0
        if desired == self.width:
            return

        center = self.pos.clone()
        center.x += self.width / 2

        self.width  = desired
        self.pos    = center.clone()
        self.pos.x -= desired / 2

        self.pos.x = max(self.pos.x, self.constrain_x.minimum)
        self.pos.x = min(self.pos.x, self.constrain_x.maximum - self.width)

        # Force the image to rebuild at the new width.
        self.image = None
