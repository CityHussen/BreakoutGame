from enum import Enum
import math
import random
from typing import override, Optional, Union
import pygame
#
from context import Context
from game_gui import FontStamp, TextAlign
from geom import BoxSide, Vec2, aabb_contains_point, line_segment_exits_aabb, ray_hits_aabb
from input_manager import ButtonState, Device as InputDevice, INPUT_MANAGER
#
from .ball   import Ball
from .block  import Block
from .paddle import Paddle
#
from .playing_field_metrics import ScreenEdge, BOARD_METRICS, BLOCK_GRID

MAX_LEVELS = 2
TRIES_PER_PLAY_SESSION = 3

_PADDLE_Y_POS = BOARD_METRICS.HEIGHT - 128
_INITIAL_BALL_Y_POS = BOARD_METRICS.CENTER.y

HUD_STRIP_HEIGHT = BOARD_METRICS.HEIGHT / 12

pygame.freetype.init()

def _assert_sane_ball_position(ball: Ball):
    """Assert that the ball is very, very roughly inside of the playing
    field, and that its position isn't otherwise garbled. This function
    has to exist because PyCharm's debugger, uh, sucks: the "Pause Script"
    button and all breakpoints can randomly just stop working; the debugger
    claims to still be connected to the running Python program when it
    clearly isn't."""

    board_size = BOARD_METRICS.SIZE.clone()
    board_size += 200
    assert not ball.pos.isnan()
    assert aabb_contains_point(BOARD_METRICS.CENTER, board_size, ball.pos)

class _TextBannerType(Enum):
    GENERAL           = 0
    SERVE_BALL_PROMPT = 1

class _TextBannerState:
    """Manage display of a simple text banner for gameplay events."""
    font = pygame.freetype.SysFont("Calibri", BOARD_METRICS.HEIGHT / 12)

    def __init__(self):
        self.time_remaining : float           = 0
        self.text           : Optional[str]   = None
        self.type           : _TextBannerType = _TextBannerType.GENERAL
        self.override_y_pos : Optional[float] = None

        self._current_stamp : Optional[FontStamp] = None

    @property
    def is_active(self) -> bool:
        return self.text is not None and self.time_remaining > 0

    def hide(self):
        """Forcibly hide the text banner."""
        self.time_remaining = 0
        self.text           = None
        self.type           = _TextBannerType.GENERAL
        self.override_y_pos = None
        self._current_stamp = None

    def show(self, text:str, time:float, y_pos:Optional[float] = None, message_type:_TextBannerType = _TextBannerType.GENERAL):
        """Set the current text banner parameters.

        If you do not specify a Y-position, then the text will be centered over
        the playing field. Note that if you want text to display indefinitely,
        you can pass `math.inf` as the time; you can then hide the message by
        calling `hide` or by clobbering it with another call to `show`."""
        self.text           = text
        self.type           = message_type
        self.time_remaining = time
        self.override_y_pos = y_pos
        self._current_stamp = None

    def set_text(self, text:str):
        """Change the displayed text, without changing the time remaining or
        any other attributes."""
        self.text           = text
        self._current_stamp = None

    def process(self, time_delta:float):
        """Should be invoked by `BreakoutContext.process`. Manages the banner's
        display time, hiding it after the remaining time has elapsed."""
        if self.is_active:
            self.time_remaining -= time_delta
            if self.time_remaining < 0:
                self.hide()

    def render(self, surface:pygame.Surface):
        """Render the banner. You can call this unconditionally; the banner is
        responsible for checking whether it has anything to display."""
        if not self.is_active:
            return

        y = self.override_y_pos
        if self.override_y_pos is None:
            y = surface.get_height() / 2

        stamp = self._current_stamp
        if not self._current_stamp:
            stamp = FontStamp(self.font, self.text)
            stamp.back_color = (0,0,0)
            stamp.text_color = (255,255,255)
            stamp.max_width  = surface.get_width()
            stamp.padding    = self.font.get_sized_height() * 0.25
            stamp.text_align = TextAlign.CENTER
            stamp.compute()
            self._current_stamp = stamp

        # Vertically center the text over the target coordinate:
        y -= stamp.height / 2

        stamp.draw(surface, 0, y)

class BreakoutContext(Context):
    def __init__(self):
        super().__init__()
        #
        self.paddle : Paddle      = Paddle()
        self.balls  : list[Ball]  = []
        self.blocks : list[Block] = []

        self.score : int = 0
        self.tries : int = TRIES_PER_PLAY_SESSION
        self.levels_cleared : int = 0

        # When the player breaks all available blocks, we go to the next level.
        # This entails spawning a new grid of blocks. However, we want to make
        # sure that we don't spawn blocks overlapping the ball, so we need to
        # wait for the ball to drop to a safe height.
        #
        # Note that the logic for this is predicated on us only having one ball
        # at a time. If multiple active balls are present in the level (e.g. if
        # someone implements a fancy powerup for that), then it's not really
        # possible to guarantee that there'll ever be a moment where all of them
        # are below the block grid. I think the only way to really handle that
        # case is by isolating each level. Like, I played DX Ball when I was a
        # kid and that had a multi-ball powerup, and it also separated levels
        # with a fade transition where after the fade, you'd have a single ball
        # in a to-be-served state.
        self.waiting_to_start_next_level : bool = False

        # Set to True when the player completes the last level. Prevents the
        # player from losing the ball and potentially game-overing right as
        # they've won, i.e. victories are never Pyrrhic.
        self.is_in_victory_state : bool = False

        self.blocks_broken            : int  = 0
        self.high_value_blocks_broken : int  = 0
        self.backwall_has_been_hit    : bool = False
        self.progress_needs_recheck   : bool = False

        self.paddle.pos.x = BOARD_METRICS.CENTER.x - self.paddle.width / 2
        self.paddle.pos.y = _PADDLE_Y_POS
        self.paddle.constrain_x.maximum = BOARD_METRICS.WIDTH

        # See documentation on the `render` handler.
        self.render_surface = pygame.Surface((BOARD_METRICS.WIDTH, BOARD_METRICS.HEIGHT))

        self.hud_strip_font    = pygame.freetype.SysFont("Calibri", HUD_STRIP_HEIGHT * 0.8)
        self.hud_strip_surface = pygame.Surface((BOARD_METRICS.WIDTH, HUD_STRIP_HEIGHT))

        self.text_banner = _TextBannerState()

    def begin_play_session(self):
        # Reset player/scoring state.
        self.score : int = 0
        self.tries : int = TRIES_PER_PLAY_SESSION
        self.levels_cleared : int = 0

        # Reset high-level progression/victory state.
        self.waiting_to_start_next_level = False
        self.is_in_victory_state         = False

        # Reset difficulty-related progression.
        self.blocks_broken            : int  = 0
        self.high_value_blocks_broken : int  = 0
        self.backwall_has_been_hit    : bool = False
        self.progress_needs_recheck   : bool = False

        # Reset paddle.
        self.paddle.width = Paddle.default_width
        self.paddle.pos.x = BOARD_METRICS.CENTER.x - self.paddle.width / 2
        self.paddle.pos.y = _PADDLE_Y_POS
        self.paddle.constrain_x.maximum = BOARD_METRICS.WIDTH

        # Reset balls and blocks.
        self.balls  = []
        self.blocks = []

        # Begin game.
        self.regenerate_block_grid()
        self.spawn_ball_to_serve()

    def regenerate_block_grid(self):
        """Delete any existing blocks, and then respawn all blocks in the usual
        grid formation -- high-value blocks nearer the backwall, and low-value
        blocks nearer the player."""
        self.blocks = []

        OFFSET_FROM_PREV_BLOCK = Block.SIZE + BLOCK_GRID.GAP_BETWEEN_BLOCKS

        for type_index in range(len(Block.TYPES)):
            # Types are listed in ascending point value order, but we generate
            # them top-to-bottom with the lowest-worth ones at the bottom, so we
            # need to generate the types in reverse order.
            current_block_type = Block.TYPES[len(Block.TYPES) - type_index - 1]

            section_y = type_index * BLOCK_GRID.ROWS_PER_BLOCK_TYPE

            for rel_grid_y in range(0, BLOCK_GRID.ROWS_PER_BLOCK_TYPE):
                grid_y = section_y + rel_grid_y
                for grid_x in range(0, BLOCK_GRID.BLOCKS_PER_ROW):
                    block = Block()
                    block.type  = current_block_type
                    block.pos.x = grid_x * OFFSET_FROM_PREV_BLOCK.x
                    block.pos.y = grid_y * OFFSET_FROM_PREV_BLOCK.y + BLOCK_GRID.Y_OFFSET

                    self.blocks.append(block)

    def destroy_block_by_player(self, block:Block):
        """Invoked when the ball hits a block while the ball is in a destructive
        state. This function should destroy the block, award points, update game
        progress, and queue up any appropriate sounds and graphics."""
        self.blocks.remove(block)
        self.score += block.score

        self.progress_needs_recheck = True
        self.blocks_broken += 1
        if block.type in (Block.Type.C, Block.Type.D):
            self.high_value_blocks_broken += 1

    def update_progress(self):
        """Sets the paddle and ball metrics (speed, size, etc.) as appropriate
        for the progress the player has made thus far."""
        if not self.progress_needs_recheck:
            return
        self.progress_needs_recheck = False

        ball_speed   = Ball.initial_speed
        paddle_width = Paddle.default_width

        if self.backwall_has_been_hit:
            paddle_width = Paddle.narrowed_width

        if self.blocks_broken >= 4:
            ball_speed = Ball.speed_increase_a
        if self.blocks_broken >= 12:
            ball_speed = Ball.speed_increase_b
        if self.high_value_blocks_broken > 0:
            ball_speed = Ball.speed_increase_c

        self.paddle.set_width(paddle_width)
        for ball in self.balls:
            ball.speed = ball_speed

    def ball_fell_in_pit(self, ball:Ball):
        """Invoked when the player fails to catch a ball and loses it. This
        function should mark the ball as destroyed and queue up any appropriate
        sounds and graphics. Don't actually remove the ball from the list of
        extant balls (our caller is still iterating it), nor handle the player
        losing a try; those steps are both handled elsewhere."""
        ball.is_destroyed = True

    def player_lost_a_try(self):
        """Invoked when the player is confirmed to have lost a try. Should show
        a message to the player as appropriate, wait for a short delay, and then
        give the player a new to-be-served ball. This function is invoked after
        the player's number of remaining tries has been decremented."""
        if self.tries > 0:
            self.text_banner.show("BALL LOST", 4)
            self._run_after(self.spawn_ball_to_serve, 4)
        else:
            self.text_banner.show("GAME OVER", 4)
            # TODO: Run defeat code in four seconds

    def player_cleared_all_blocks(self):
        self.levels_cleared += 1
        if self.levels_cleared == MAX_LEVELS:
            self.text_banner.show("VICTORY", 4)
            self.is_in_victory_state = True

            # TODO: Kick-off victory state behaviors
            #  - Freeze ball
            #  - Show victory graphics
            #  - Go to high-score entry screen after a short delay
        else:
            self.text_banner.show("LEVEL CLEAR", math.inf, BLOCK_GRID.CENTER.y)

            self.waiting_to_start_next_level = True

    def handle_next_level_start(self):
        """Check if we're waiting until it's safe to start the next level. If
        we're waiting, and all wait conditions are satisfied, then start the
        next level by spawning a new grid of blocks."""
        if not self.waiting_to_start_next_level:
            return

        no_balls_in_grid = True
        for ball in self.balls:
            if ball.pos.y < _INITIAL_BALL_Y_POS:
                no_balls_in_grid = False

        if no_balls_in_grid:
            self.regenerate_block_grid()
            self.text_banner.hide() # hide "LEVEL CLEAR"
            self.waiting_to_start_next_level = False

    def spawn_ball_to_serve(self):
        if len(self.balls) > 0:
            return
        ball = Ball()
        ball.is_active = False
        ball.pos.x = BOARD_METRICS.CENTER.x
        ball.pos.y = _INITIAL_BALL_Y_POS
        self.balls.append(ball)

        self.text_banner.show("PRESS SPACE TO SERVE THE BALL", math.inf, BLOCK_GRID.CENTER.y, _TextBannerType.SERVE_BALL_PROMPT)

    def simulate_ball(self, ball:Ball, move_by:float):
        """Simulate the ball's movement forward, with a priori collision checks
        to ensure the ball doesn't clip. The `move_by` parameter, when you
        initially call this function, should be the ball's speed (i.e. the
        length of its velocity vector) times the time delta."""

        #
        # TODO: In order to properly handle corner collisions, do we need to use
        # two rays? Specifically: if we project forward from the ball's center
        # to its edge, in the direction of its velocity, and treat that point on
        # its edge as its "front," then we might need to raycast from its "side"
        # points instead of from its center.
        #

        ball_forward = ball.velocity.normalized()

        nearest_collidable : Union[None, Block, Paddle, ScreenEdge] = None
        nearest_distance   : Optional[float]                        = None
        nearest_side       : Optional[BoxSide]                      = None

        def is_nearest_so_far(distance:Optional[float]) -> bool:
            if distance is None:
                return False
            if distance < 0:
                return False
            if distance > move_by:
                return False
            return nearest_distance is None or distance < nearest_distance

        # Check for collision with a block.
        for block in self.blocks:
            side, distance = ray_hits_aabb(ball.pos, ball_forward, block.center, block.size)
            if not is_nearest_so_far(distance):
                continue
            if side is None or distance > move_by or distance < 0:
                continue
            if nearest_collidable is None or distance < nearest_distance:
                nearest_collidable = block
                nearest_distance   = distance
                nearest_side       = side

        # Check for collision with paddle.
        side, distance = ray_hits_aabb(ball.pos, ball_forward, self.paddle.center, self.paddle.size)
        if is_nearest_so_far(distance):
            nearest_collidable = self.paddle
            nearest_distance   = distance
            nearest_side       = side

        # Check for exiting the playing field bounds.
        #
        # This check is slightly more involved. We don't want the ball to bounce
        # off of the bottom edge. Rather, we want it to pass off-screen before
        # we treat it as having collided with the bottom edge. This means we
        # need to inflate the playing field box downward by at least the ball's
        # radius.
        board_center = BOARD_METRICS.CENTER.clone() # TODO: pre-cache in context constructor?
        board_size   = BOARD_METRICS.SIZE.clone()   # TODO: pre-cache in context constructor?
        board_size.y   += Ball.RADIUS * 2
        board_center.y += Ball.RADIUS
        #
        side, distance = line_segment_exits_aabb(
            ball.pos,
            ball.pos + ball_forward * move_by,
            board_center,
            board_size
        )
        if is_nearest_so_far(distance):
            #
            # The ball is going to move outside of the playing field bounds on
            # this frame, if its movement is not impeded. (We still want to run
            # distance checks, in case some other object is between the ball and
            # the screen edge; the ball's collision with that other object will
            # keep it on-screen, I expect.)
            #
            nearest_distance = distance
            nearest_side     = side
            match side:
                case BoxSide.TOP:
                    nearest_collidable = ScreenEdge.TOP
                case BoxSide.BOTTOM:
                    nearest_collidable = ScreenEdge.BOTTOM
                case BoxSide.LEFT:
                    nearest_collidable = ScreenEdge.LEFT
                case BoxSide.RIGHT:
                    nearest_collidable = ScreenEdge.RIGHT

        if nearest_distance is not None and nearest_distance > move_by:
            nearest_distance   = None
            nearest_collidable = None

        #
        # We have identified the object that the ball has collided with, if any.
        # Time to actually handle the collision!
        #

        if nearest_collidable is None:
            ball.pos += ball_forward.scale(move_by)
            return

        hit_edge_position = ball.pos + ball_forward.scaled(nearest_distance)
        hit_ball_position = hit_edge_position - ball_forward.scaled(Ball.RADIUS)

        bounce_velocity = ball.velocity
        if nearest_collidable is self.paddle:
            ball.compute_paddle_bounce_angle(self.paddle, hit_edge_position)
            bounce_velocity = ball.velocity
            assert bounce_velocity.y < 0, "Ball must bounce upward from the paddle"
        else:
            if nearest_collidable == ScreenEdge.BOTTOM:
                assert bounce_velocity.y > 0, "Ball must be moving downward to hit the bottom of the playing field"
                pass # continue the ball's trajectory downward
            else:
                match nearest_side:
                    case BoxSide.TOP | BoxSide.BOTTOM:
                        bounce_velocity.y = -bounce_velocity.y
                    case BoxSide.LEFT | BoxSide.RIGHT:
                        bounce_velocity.x = -bounce_velocity.x

        ball.pos      = hit_ball_position
        ball.velocity = bounce_velocity
        _assert_sane_ball_position(ball)

        if ball.is_destructive:
            if isinstance(nearest_collidable, Block):
                self.destroy_block_by_player(nearest_collidable)
                ball.is_destructive = False
        else:
            if nearest_collidable is self.paddle or nearest_collidable == ScreenEdge.BACKWALL:
                ball.is_destructive = True

        if nearest_collidable == ScreenEdge.TOP:
            self.backwall_has_been_hit  = True
            self.progress_needs_recheck = True
        if nearest_collidable == ScreenEdge.BOTTOM:
            self.ball_fell_in_pit(ball)

        move_by -= nearest_distance
        if move_by > 0:
            #
            # Ensure we don't "lose" any speed: recursively simulate forward
            # ball movement until we've "used up" all of the speed for this
            # time delta.
            #
            self.simulate_ball(ball, move_by)

    #
    # Context handlers below.
    #

    @override
    def process(self, time_delta:float):
        super().process(time_delta)

        self.text_banner.process(time_delta)

        dir_move = INPUT_MANAGER.state.directional_move

        if not dir_move.is_zero():
            self.paddle.attempt_horizontal_move(dir_move.x * Paddle.maximum_speed * time_delta)

        if INPUT_MANAGER.state.serve_ball == ButtonState.DOWN:
            for ball in self.balls:
                if not ball.is_active:
                    ball.is_active = True
                    ball.velocity.y = 1  # toward player
                    ball.velocity.x = random.random() * 2 - 1
                    ball.speed = Ball.initial_speed

                    # Hide the instructions for serving the ball
                    self.text_banner.hide()

        if INPUT_MANAGER.state.ui_toggle_pause == ButtonState.DOWN:
            # TODO: Open pause menu
            pass

        ball_count_prior : int  = len(self.balls)
        ball_is_inactive : bool = True
        for ball in self.balls:
            if ball.is_active:
                ball_is_inactive = False
                self.simulate_ball(ball, ball.velocity.length() * time_delta)
        self.balls = [ball for ball in self.balls if not ball.is_destroyed]

        if self.text_banner.type == _TextBannerType.SERVE_BALL_PROMPT:
            if ball_is_inactive and len(self.balls) > 0:
                #
                # Update the prompt to serve the ball in real-time, based on the
                # player's input device.
                #
                if INPUT_MANAGER.state.last_keynav_device == InputDevice.KEYBOARD:
                    self.text_banner.set_text("PRESS SPACE TO SERVE THE BALL")
                elif INPUT_MANAGER.state.last_keynav_device == InputDevice.GAMEPAD:
                    self.text_banner.set_text("PRESS A TO SERVE THE BALL")


        self.handle_next_level_start()
        self.update_progress()

        if len(self.blocks) == 0:
            self.player_cleared_all_blocks()

        if not self.is_in_victory_state:
            if ball_count_prior > 0 and len(self.balls) <= 0:
                self.tries -= 1
                self.player_lost_a_try()

    def _render_hud_strip(self):
        #
        # TODO: Potential optimization: remember the last score, tries, and
        #       level we painted, and only clear-and-repaint the HUD strip if
        #       any of those values have changed.
        #
        self.hud_strip_surface.fill((0, 0, 0))

        padding_top = HUD_STRIP_HEIGHT * 0.1
        dst_w = self.hud_strip_surface.get_width()

        stamp = FontStamp(self.hud_strip_font, f"{self.score} pts.")
        stamp.text_color = (255,255,255)
        stamp.compute()
        stamp.draw(self.hud_strip_surface, 0, padding_top)

        stamp = FontStamp(self.hud_strip_font, f"Tries: {self.tries}")
        stamp.text_color = (255, 255, 255)
        stamp.compute()
        stamp.draw(self.hud_strip_surface, dst_w - stamp.width, padding_top)

        level_text = f"LEVEL {self.levels_cleared + 1}"
        if self.levels_cleared == MAX_LEVELS:
            level_text = "YOU WIN"
        stamp = FontStamp(self.hud_strip_font, level_text)
        stamp.text_color = (255, 255, 255)
        stamp.compute()
        stamp.draw(self.hud_strip_surface, (dst_w - stamp.width) / 2, padding_top)

    @override
    def render(self, surface:pygame.Surface):
        """For rendering the main gameplay loop, we use an off-screen canvas
        (`self.render_surface`) sized based on the grid of blocks. We then
        downscale or upscale that as necessary to fit the program's main display
        surface (the `surface` argument to this function)."""
        super().render(surface)

        self.render_surface.fill((255, 255, 255))
        #
        self.paddle.draw(self.render_surface)
        for ball in self.balls:
            ball.draw(self.render_surface)
        for block in self.blocks:
            block.draw(self.render_surface)
        self.text_banner.render(self.render_surface)

        self._render_hud_strip()

        src_hud_h   = self.hud_strip_surface.get_height()
        src_board_h = self.render_surface.get_height()

        src_w = self.render_surface.get_width()
        src_h = src_board_h + src_hud_h

        available_w = surface.get_width()
        available_h = surface.get_height()

        dst_scale = min(available_w / src_w, available_h / src_h)
        dst_w     = src_w * dst_scale
        dst_h     = src_h * dst_scale

        # Top-left of downscaled render:
        dst_x = max(0.0, (available_w - dst_w) / 2)
        dst_y = max(0.0, (available_h - dst_h) / 2)

        # Metrics for downscaled HUD strip:
        dst_hud_y = dst_y
        dst_hud_h = src_hud_h * dst_scale

        # Metrics for downscaled playing field:
        dst_board_y = dst_hud_y + dst_hud_h
        dst_board_h = src_board_h * dst_scale

        # Draw the board.
        scaled = pygame.transform.smoothscale(self.render_surface, (dst_w, dst_board_h))
        surface.blit(scaled, (dst_x, dst_board_y))

        # Draw the HUD.
        scaled = pygame.transform.smoothscale(self.hud_strip_surface, (dst_w, dst_hud_h))
        surface.blit(scaled, (dst_x, dst_hud_y))

BREAKOUT_CONTEXT = BreakoutContext()
