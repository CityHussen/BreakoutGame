from .vec2 import Vec2

def aabb_intersects_circle(
    box_center:Vec2,
    box_sizes:Vec2, # Vec2(width, height)
    circle_center:Vec2,
    circle_radius:float
) -> bool:
    p = circle_center - box_center
    box_halfwidths = box_sizes / 2

    # use a distance field for the box, per Inigo Quilez:
    # https://www.youtube.com/watch?v=62-pRVZuS5c
    gap   = abs(p) - box_halfwidths
    gap.x = max(gap.x, 0)
    gap.y = max(gap.y, 0)
    distance = gap.length()

    return distance < circle_radius
