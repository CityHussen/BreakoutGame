from .vec2 import Vec2
from .capsule_intersects_circle import capsule_intersects_circle

def capsule_contains_point(
    capsule_end_circle_a:Vec2,
    capsule_end_circle_b:Vec2,
    capsule_end_radius:float,
    #
    point:Vec2
) -> bool:
    return capsule_intersects_circle(
        capsule_end_circle_a,
        capsule_end_circle_b,
        capsule_end_radius,
        point,
        0
    )
