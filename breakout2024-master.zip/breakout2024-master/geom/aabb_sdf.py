from .vec2 import Vec2

def aabb_sdf(
    box_center : Vec2,
    box_sizes  : Vec2, # (width, height)
    point      : Vec2
) -> float:
    """Treats an axis-aligned bounding box as a signed distance field, and
    returns the point's distance within that field. The absolute value of the
    return value is the distance from `point` to the box's nearest edge. If the
    return value is positive, then the point is outside the box; if the point is
    zero or negative, then the point is within the box."""

    point -= box_center
    box_halfwidths = box_sizes / 2

    gap = abs(point) - box_halfwidths

    gap_pos   = gap.clone()
    gap_pos.x = max(gap_pos.x, 0)
    gap_pos.y = max(gap_pos.y, 0)
    distance = gap_pos.length()

    penetration_neg = min(0, max(gap.x, gap.y, gap.z))
    return distance + penetration_neg
