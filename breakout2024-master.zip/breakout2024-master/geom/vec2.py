from math import atan2, cos, sin, sqrt, isnan
from numbers import Real
from typing import Self, Optional, Tuple, Union

class Vec2:
    """A mathematical vector with two components, x and y."""

    def __init__(self, a: Optional[Union[Self, float]] = None, b: Optional[float] = None):
        self.x:float = 0
        self.y:float = 0
        if a is not None:
            if isinstance(a, Vec2):
                self.x = a.x
                self.y = a.y
            elif isinstance(a, Real):
                self.x = float(a)
                if b is not None:
                    self.y = float(b)

    def clone(self) -> "Vec2":
        """Return a copy of this vector."""
        return Vec2(self)

    def tuple(self) -> Tuple[float, float]:
        return self.x, self.y

    def __repr__(self):
        return f"Vec2({self.x}, {self.y})"

    def __str__(self):
        return f"({self.x}, {self.y})"

    def __eq__(self, other) -> bool:
        if not isinstance(other, Vec2):
            return False
        return self.x == other.x and self.y == other.y

    def __neg__(self) -> "Vec2": # const
        return Vec2(-self.x, -self.y)

    def __abs__(self) -> "Vec2":
        return Vec2(abs(self.x), abs(self.y))

    def __add__(self, other): # const
        if isinstance(other, Vec2):
            return Vec2(self.x+other.x, self.y+other.y)
        elif isinstance(other, Real):
            return Vec2(self.x+other, self.y+other)
        else:
            return NotImplemented

    def __sub__(self, other): # const
        if isinstance(other, Vec2):
            return Vec2(self.x-other.x, self.y-other.y)
        elif isinstance(other, Real):
            return Vec2(self.x-other, self.y-other)
        else:
            return NotImplemented

    def __mul__(self, other): # const
        if isinstance(other, Vec2):
            return self.dot(other)
        elif isinstance(other, Real):
            return self.scaled(other)
        else:
            return NotImplemented
    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other): # const
        if isinstance(other, Real):
            return Vec2(self.x/other, self.y/other)
        return NotImplemented

    def angle(self) -> float:
        """Return this vector's angle in radians. Angles are counterclockwise
        with the unit vector for angle 0 being (1, 0)."""
        return atan2(self.y, self.x)

    def is_zero(self) -> bool:
        """Check if the vector is (basically) zero, accounting for floating-
        point imprecision and ignoring extremely small values."""
        EPSILON = 0.000001
        if abs(self.x) > EPSILON:
            return False
        if abs(self.y) > EPSILON:
            return False
        return True

    def dot(self, other: Self) -> float:
        """Compute the dot product of this vector and another."""
        return self.x*other.x + self.y*other.y

    def isnan(self) -> bool:
        """Check if any component of the vector is NaN."""
        return isnan(self.x) or isnan(self.y)

    def length(self) -> float: # const
        return sqrt(self.x**2 + self.y**2)

    def length_sq(self) -> float: # micro-optimization
        """Return this vector's length squared, equivalent to taking the dot
        product of this vector and itself. This skips a square-root operation
        which can in some cases be a micro-optimization."""
        return self.x**2 + self.y**2

    def normalize(self) -> Self:
        """Set this vector's length to one."""
        length = self.length()
        self.x /= length
        self.y /= length
        return self
    def normalized(self) -> "Vec2": # const
        """Return a new vector with length 1, pointing in the same direction as
        this vector."""
        return Vec2(self).normalize()

    def rotated(self, radians:Real, about:Optional[Self] = None) -> "Vec2":
        """Rotate the vector counterclockwise by the given angle, preserving its
        length, and return the result as a new vector."""
        out = Vec2(self)
        if about is not None:
            out.x -= about.x
            out.y -= about.y

        rx = cos(radians * out.x) - sin(radians * out.y)
        ry = sin(radians * out.x) + cos(radians * out.y)
        out.x = rx
        out.y = ry

        if about is not None:
            out.x += about.x
            out.y += about.y

        return out

    def projected(self, axis:Self) -> "Vec2":
        """Project this vector onto the given axis, and return the result as a
        new vector."""
        axis = axis.normalized()
        return axis.scale(self.dot(axis))

    def scale(self, mult:Real) -> Self:
        """Change the vector's length."""
        self.x *= mult
        self.y *= mult
        return self
    def scaled(self, mult:Real) -> "Vec2": # const
        """Return a new vector equivalent to this vector but with a scaled
        length."""
        return Vec2(self).scale(mult)

    def set_angle(self, radians:Real) -> Self:
        """Overwrite the vector's angle while preserving its length."""
        length = self.length()
        self.x = cos(radians)
        self.y = sin(radians)
        self.scale(length)
        return self
