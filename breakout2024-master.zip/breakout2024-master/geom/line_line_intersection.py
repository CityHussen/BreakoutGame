from typing import Union
from .vec2 import Vec2

def line_line_intersection(
    line_a_start : Vec2, # (x1, y1)
    line_a_end   : Vec2, # (x2, y2)
    line_b_start : Vec2, # (x3, y3)
    line_b_end   : Vec2, # (x4, y4)
    lines_are_infinite : bool = False
) -> Union[bool, Vec2]:
    """Compute the intersection point between two lines or two line segments.
    If they don't intersect, returns False. If the lines are co-linear, returns
    True. If the lines intersect, returns the intersection point as a Vec2."""
    A : Vec2 = line_a_end - line_a_start
    B : Vec2 = line_b_start - line_b_end
    C : Vec2 = line_a_start - line_b_start
    if lines_are_infinite:
        u     : float = line_a_start.x*line_a_end.y - line_a_start.y*line_a_end.x
        v     : float = line_b_start.x*line_b_end.y - line_b_start.y*line_b_end.x
        denom : float = A.x*B.y - A.y*B.x

        intersection_point : Vec2 = Vec2()
        intersection_point.x = (u*B.x - A.x*v) / denom
        intersection_point.y = (u*B.y - A.y*v) / denom
        return intersection_point

    denom   : float = A.y*B.x - A.x*B.y
    t_numer : float = B.y*C.x - B.x*C.y
    u_numer : float = A.x*C.y - A.y*C.x

    if denom > 0:
        if t_numer < 0 or t_numer > denom:
            return False
        if u_numer < 0 or u_numer > denom:
            return False
    elif denom < 0:
        if t_numer > 0 or t_numer < denom:
            return False
        if u_numer > 0 or u_numer < denom:
            return False
    else:
        return True # line segments are identical/co-linear

    t = t_numer / denom
    return line_a_start + t*(line_a_end - line_a_start)