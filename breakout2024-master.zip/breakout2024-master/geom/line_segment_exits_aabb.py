from .vec2 import Vec2
from .ray_hits_aabb import ray_hits_aabb

def line_segment_exits_aabb(
    line_start: Vec2,
    line_end:   Vec2,
    box_center: Vec2,
    box_sizes:  Vec2
):
    ray_origin    = line_end
    ray_span      = line_start - line_end
    ray_length    = ray_span.length()
    ray_direction = ray_span / ray_length

    edge, distance = ray_hits_aabb(ray_origin, ray_direction, box_center, box_sizes)
    if distance is None or distance > ray_length:
        return None, None
    return edge, distance