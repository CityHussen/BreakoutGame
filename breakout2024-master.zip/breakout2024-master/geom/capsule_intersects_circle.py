from .vec2 import Vec2

def capsule_intersects_circle(
    capsule_end_circle_a:Vec2,
    capsule_end_circle_b:Vec2,
    capsule_end_radius:float,
    #
    circle_center:Vec2,
    circle_radius:float
) -> bool:
    # use a signed distance function. Inigo Quilez lists some here:
    # https://iquilezles.org/articles/distfunctions/

    capsule_spine:Vec2 = capsule_end_circle_b - capsule_end_circle_a
    gap_to_a:Vec2      = circle_center - capsule_end_circle_a

    h:float = gap_to_a.dot(capsule_spine) / capsule_spine.length_sq()
    h:float = min(max(h, 0), 1)

    distance:float = (gap_to_a - (capsule_spine * h)).length() - capsule_end_radius

    return distance <= circle_radius
