import math
from typing import Tuple, Union
from .box_side import BoxSide
from .vec2 import Vec2

def ray_hits_aabb(
    ray_origin    : Vec2,
    ray_direction : Vec2, # must be normalized
    box_center    : Vec2,
    box_size      : Vec2
) -> Union[Tuple[BoxSide, float], Tuple[None, None]]:
    """Checks if the specified ray would intersect the specified AABB. If so,
    returns the box edge that the ray hits, and the hit distance from the ray's
    origin."""

    # Variation on:
    # https://gamedev.stackexchange.com/questions/18436/most-efficient-aabb-vs-ray-collision-algorithms/18459#18459
    # https://computergraphics.stackexchange.com/questions/9504/ray-vs-aabb-algorithm-that-also-gives-which-side-was-hit
    #
    # The first link identifies a generalized algorithm to tell whether a ray
    # will hit an AABB, and if so, at what distance. The second link extends the
    # algorithm to identify which surface of the AABB (top/left/right/bottom) is
    # being hit.

    dir_frac = ray_direction.clone()
    dir_frac.x = 1 / dir_frac.x
    dir_frac.y = 1 / dir_frac.y

    box_halfwidths : Vec2 = box_size / 2
    box_min        : Vec2 = box_center - box_halfwidths
    box_max        : Vec2 = box_center + box_halfwidths

    x_span_a : float = (box_min.x - ray_origin.x) * dir_frac.x
    x_span_b : float = (box_max.x - ray_origin.x) * dir_frac.x
    y_span_a : float = (box_min.y - ray_origin.y) * dir_frac.y
    y_span_b : float = (box_max.y - ray_origin.y) * dir_frac.y

    x_span_min = min(x_span_a, x_span_b)
    y_span_min = min(y_span_a, y_span_b)

    maxxest_min = max(x_span_min, y_span_min)
    minnest_max = min(max(x_span_a, x_span_b), max(y_span_a, y_span_b))
    if math.isnan(maxxest_min):
        maxxest_min = math.inf
    if math.isnan(minnest_max):
        minnest_max = -math.inf

    if maxxest_min > minnest_max:
        #
        # No intersection, not even with a bidirectional line.
        #
        return None, None
    if maxxest_min < 0:
        #
        # Intersection is behind the ray, OR the ray origin is inside the box.
        #
        return None, None

    # Other notes:
    # if maxxest_min > 0 and minnest_max > 0: the ray origin is inside the box

    hit_distance = maxxest_min

    side = BoxSide.TOP
    if hit_distance == x_span_a:
        side = BoxSide.LEFT
    elif hit_distance == x_span_b:
        side = BoxSide.RIGHT
    elif hit_distance == y_span_a:
        side = BoxSide.TOP
    elif hit_distance == y_span_b:
        side = BoxSide.BOTTOM

    return side, hit_distance