from .aabb_intersects_circle import aabb_intersects_circle
from .vec2 import Vec2

def aabb_contains_point(
    box_center:Vec2,
    box_sizes:Vec2,
    point:Vec2
) -> bool:
    box_halfwidths = box_sizes / 2

    # use a distance field to see if the point is in the box
    # math per Inigo Quilez:
    # https://www.youtube.com/watch?v=62-pRVZuS5c
    gap   = abs(point - box_center) - box_halfwidths
    gap.x = max(gap.x, 0)
    gap.y = max(gap.y, 0)

    return gap.length() == 0
