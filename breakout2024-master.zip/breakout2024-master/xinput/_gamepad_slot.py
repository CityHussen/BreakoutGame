import ctypes
from ._native import *

class GamepadSlot:
    """XInput supports up to four connected gamepads at a time: one per port.
    This limitation is carried over from the Xbox consoles' design but is part
    of the API contract on PC as well. The details of how XInput maps a PC's
    physical USB ports and wireless controller connections to "Xbox controller
    ports" are left completely unexplained in the documentation (see below):

        https://learn.microsoft.com/en-us/windows/win32/xinput/getting-started-with-xinput?redirectedfrom=MSDN#multiple-controllers

    That documentation also hasn't been updated since the Xbox 360 days: the
    only real explanation it gives about handling multiple controllers is based
    on physical features that aren't present on Xbox controllers post-360. Fun.

    Anyway, this class represents gamepad state for a single port/slot."""
    def __init__(self, slot:int):
        self.slot       : int  = slot
        self.connected  : bool = False
        self.changed    : bool = False

        self.last_gamepad  : XINPUT_GAMEPAD = XINPUT_GAMEPAD()
        self.current_state : XINPUT_STATE   = XINPUT_STATE()

    @property
    def last_packet_id(self) -> int:
        return self.current_state.dwPacketNumber

    @property
    def left_trigger(self) -> float:
        return float(self.current_state.gamepad.bLeftTrigger) / 255

    @property
    def right_trigger(self) -> float:
        return float(self.current_state.gamepad.bRightTrigger) / 255

    def is_button_down(self, button:int) -> bool:
        if 0 <= button < 16:
            return (self.current_state.gamepad.wButtons & (1 << button)) != 0
        return False

    def has_button_changed(self, button:int) -> bool:
        if 0 <= button < 16:
            prior = (self.last_gamepad.wButtons & (1 << button)) != 0
            return self.is_button_down(button) != prior
        return False

    def update(self):
        if DLL is None:
            return
        last_packet = self.last_packet_id

        #self.last_gamepad = self.current_state.gamepad
        #
        # The above code doesn't overwrite `last_gamepad` with the previous
        # frame's state; it just sets `last_gamepad` to refer to the same
        # object, which we then overwrite with the DLL call. Let's abuse ctypes
        # to force an overwrite.
        #
        # Per https://stackoverflow.com/a/1470554:
        #
        ctypes.pointer(self.last_gamepad)[0] = self.current_state.gamepad

        result : int = DLL.XInputGetState(self.slot, ctypes.byref(self.current_state))
        if result == ERROR_DEVICE_NOT_CONNECTED:
            self.changed   = self.connected == True
            self.connected = False
            return
        if result != ERROR_SUCCESS:
            raise RuntimeError(f"Failed to update state for gamepad {self.slot}: Win32 error {result}")

        self.connected = True
        self.changed   = (not self.connected) or self.last_packet_id != last_packet