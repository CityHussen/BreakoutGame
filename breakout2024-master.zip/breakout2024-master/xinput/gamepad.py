from enum import IntEnum
from typing import Optional
from ._native import XINPUT_GAMEPAD_TRIGGER_THRESHOLD, XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE, XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE
from ._gamepad_slot import GamepadSlot
from geom import Vec2

class Button(IntEnum):
    DPAD_UP      = 0
    DPAD_DOWN    = 1
    DPAD_LEFT    = 2
    DPAD_RIGHT   = 3
    START        = 4
    BACK         = 5
    LS_CLICK     = 6
    RS_CLICK     = 7
    LB           = 8
    LEFT_BUMPER  = LB
    RB           = 9
    RIGHT_BUMPER = RB
    # Bit 10 is unused.
    # Bit 11 is unused.
    A            = 12
    B            = 13
    X            = 14
    Y            = 15
    #
    # Convenience constants:
    #
    LT            = 16
    LEFT_TRIGGER  = LT
    RT            = 17
    RIGHT_TRIGGER = RT

class Gamepad:
    """Interface for checking the state of a connected XInput-compatible input
    device. In terms of implementation, this is a read-only wrapper around the
    internal GamepadSlot class, with some additional conveniences added.

    In general, accessors for buttons, sticks, etc., will not check whether the
    gamepad is still connected. You should run that check yourself before you
    query anything; it'd be more efficient than repeatedly re-running it for
    each individual physical input you query. If you do try to retrieve state
    for a disconnected gamepad, I'd *expect* you to get the last-known input
    state, but it really depends on whether the underlying XInputGetState C API
    modifies the XINPUT_STATE it's given when the gamepad is disconnected (the
    documentation isn't explicit about this but implies, by what it omits, that
    no modifications are made)."""

    LEFT_STICK_DEADZONE_PERCENT  = float(XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE)  / 32767.5
    RIGHT_STICK_DEADZONE_PERCENT = float(XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE) / 32767.5

    def __init__(self, src:GamepadSlot):
        self._data : GamepadSlot = src

        self.ignored_buttons : int = 0 # bitmask

    @property
    def connected(self) -> bool:
        return self._data.connected

    @property
    def may_have_changed(self) -> bool:
        """If False, then the gamepad's state has not changed during this frame;
        you can skip checking the buttons and joysticks and whatnot."""
        return self._data.changed

    @property
    def slot(self) -> int:
        return self._data.slot

    @property
    def left_trigger(self) -> float:
        """The amount by which the left trigger is depressed, normalized to the
        range [0, 1]."""
        return self._data.left_trigger

    @property
    def right_trigger(self) -> float:
        """The amount by which the right trigger is depressed, normalized to the
        range [0, 1]."""
        return self._data.right_trigger

    @property
    def left_stick_raw(self) -> Vec2:
        """Returns the left stick vector without applying deadzones. Vector
        components are normalized to the range [-1, 1]. Negative values point
        down and to the left; positive values point up and to the right."""
        gamepad = self._data.current_state.gamepad
        stick   = (Vec2(float(gamepad.sThumbLX), float(gamepad.sThumbLY)) + 0.5) / 32767.5
        return stick

    @property
    def right_stick_raw(self) -> Vec2:
        """Returns the right stick vector without applying deadzones. Vector
        components are normalized to the range [-1, 1]. Negative values point
        down and to the left; positive values point up and to the right."""
        gamepad = self._data.current_state.gamepad
        stick   = (Vec2(gamepad.sThumbRX, gamepad.sThumbRY) + 0.5) / 32767.5
        return stick

    @property
    def left_stick(self) -> Vec2:
        """Returns the left stick vector, with deadzones applied per-axis.
        Vector components are normalized to the range [-1, 1]. Negative values
        point down and to the left; positive values point up and to the
        right."""
        deadzone = self.LEFT_STICK_DEADZONE_PERCENT
        stick    = self.left_stick_raw
        if abs(stick.x) < deadzone:
            stick.x = 0
        if abs(stick.y) < deadzone:
            stick.y = 0
        return stick

    @property
    def right_stick(self) -> Vec2:
        """Returns the right stick vector, with deadzones applied per-axis.
        Vector components are normalized to the range [-1, 1]. Negative values
        point down and to the left; positive values point up and to the
        right."""
        deadzone = self.RIGHT_STICK_DEADZONE_PERCENT
        stick    = self.right_stick_raw
        if abs(stick.x) < deadzone:
            stick.x = 0
        if abs(stick.y) < deadzone:
            stick.y = 0
        return stick

    #

    def ignore_button(self, button:Button):
        """Mark a button as ignored. Buttons will stop being ignored when they
        cease to be down."""
        self.ignored_buttons |= 1 << button

    def set_button_ignored(self, button:Button, ignore:bool):
        bitmask = 1 << button
        if ignore:
            self.ignored_buttons |= bitmask
        else:
            self.ignored_buttons &= ~bitmask

    def ignore_all_currently_down_buttons(self):
        gamepad = self._data.current_state.gamepad
        self.ignored_buttons |= gamepad.wButtons

    def stop_ignoring_buttons_by_mask(self, mask:int):
        """Provided so the gamepad manager can efficiently clear ignore state on
        buttons that are no longer down. Bits that are cleared in `mask` will be
        cleared in the ignored button mask."""
        self.ignored_buttons &= mask

    def button_is_ignored(self, button:Button) -> bool:
        return self.ignored_buttons & (1 << button) != 0

    #

    def any_buttons_down(self, include_ignored:bool = False) -> bool:
        gamepad = self._data.current_state.gamepad

        buttons_mask = gamepad.wButtons
        if not include_ignored:
            buttons_mask &= ~self.ignored_buttons

        if buttons_mask != 0:
            return True

        trigger_l = gamepad.bLeftTrigger  > XINPUT_GAMEPAD_TRIGGER_THRESHOLD
        trigger_r = gamepad.bRightTrigger > XINPUT_GAMEPAD_TRIGGER_THRESHOLD
        if not include_ignored:
            if self.button_is_ignored(Button.LT):
                trigger_l = False
            if self.button_is_ignored(Button.RT):
                trigger_r = False
        if trigger_l or trigger_r:
            return True

        return False

    def any_sticks_moved(self) -> bool:
        """Returns True if any sticks on this gamepad are moved past their
        per-axis deadzones."""
        gamepad = self._data.current_state.gamepad
        if abs(gamepad.sThumbLX) > XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE:
            return True
        if abs(gamepad.sThumbLY) > XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE:
            return True
        if abs(gamepad.sThumbRX) > XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE:
            return True
        if abs(gamepad.sThumbRY) > XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE:
            return True
        return False

    def any_inputs_being_made(self, include_ignored:bool = False) -> bool:
        return self.any_buttons_down(include_ignored) or self.any_sticks_moved()

    def is_button_down(self, button:Button, include_ignored:bool = False) -> bool:
        if (not include_ignored) and self.button_is_ignored(button):
            return False

        if button in (Button.LT, Button.RT):
            gamepad = self._data.current_state.gamepad
            if button is Button.LT:
                return gamepad.bLeftTrigger > XINPUT_GAMEPAD_TRIGGER_THRESHOLD
            if button is Button.RT:
                return gamepad.bRightTrigger > XINPUT_GAMEPAD_TRIGGER_THRESHOLD

        return self._data.is_button_down(button)

    def has_button_changed(self, button:Button) -> bool:
        if button in (Button.LT, Button.RT):
            current  = self._data.current_state.gamepad
            previous = self._data.last_gamepad
            if button is Button.LT:
                after = current.bLeftTrigger   > XINPUT_GAMEPAD_TRIGGER_THRESHOLD
                prior = previous.bLeftTrigger  > XINPUT_GAMEPAD_TRIGGER_THRESHOLD
            elif button is Button.RT:
                after = current.bRightTrigger  > XINPUT_GAMEPAD_TRIGGER_THRESHOLD
                prior = previous.bRightTrigger > XINPUT_GAMEPAD_TRIGGER_THRESHOLD
            return after != prior

        return self._data.has_button_changed(button)

    def button_pressed_now(self, button:Button) -> bool:
        """Returns true if the button was pressed down on this frame, or False
        otherwise."""
        return self.is_button_down(button) and self.has_button_changed(button)

    def button_relased_now(self, button:Button) -> bool:
        """Returns true if the button was released on this frame, or False
        otherwise."""
        return (not self.is_button_down(button)) and self.has_button_changed(button)
