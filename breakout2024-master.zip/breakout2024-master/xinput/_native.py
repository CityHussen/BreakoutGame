import ctypes
import sys

DLL = ctypes.windll.xinput1_4 if sys.platform == "win32" else None

ERROR_DEVICE_NOT_CONNECTED = 1167
ERROR_SUCCESS = 0

XINPUT_GAMEPAD_TRIGGER_THRESHOLD    = 30
XINPUT_GAMEPAD_LEFT_THUMB_DEADZONE  = 7849
XINPUT_GAMEPAD_RIGHT_THUMB_DEADZONE = 8689
class XINPUT_GAMEPAD(ctypes.Structure):
    _fields_ = [
        ("wButtons",      ctypes.c_ushort), # bitmask
        ("bLeftTrigger",  ctypes.c_ubyte),  # how far the trigger is down: [0, 255]
        ("bRightTrigger", ctypes.c_ubyte),  # how far the trigger is down: [0, 255]
        ("sThumbLX",      ctypes.c_short),  # [-32768, 32767]
        ("sThumbLY",      ctypes.c_short),  # [-32768, 32767]
        ("sThumbRX",      ctypes.c_short),  # [-32768, 32767]
        ("sThumbRY",      ctypes.c_short),  # [-32768, 32767]
    ]

class XINPUT_STATE(ctypes.Structure):
    _fields_ = [
        ("dwPacketNumber", ctypes.c_ulong),
        ("gamepad",        XINPUT_GAMEPAD),
    ]

class XINPUT_VIBRATION(ctypes.Structure):
    _fields_ = [
        ("wLeftMotorSpeed",  ctypes.c_ushort),
        ("wRightMotorSpeed", ctypes.c_ushort),
    ]

class XINPUT_BATTERY_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BatteryType",  ctypes.c_ubyte),
        ("BatteryLevel", ctypes.c_ubyte),
    ]