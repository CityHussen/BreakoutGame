from typing import Optional
from ._gamepad_slot import GamepadSlot
from .gamepad import Button, Gamepad
from ._native import DLL

class _XInputManager:
    def __init__(self):
        self._slots   : list[GamepadSlot] = []
        self.gamepads : list[Gamepad]     = []

        self.supported : bool = DLL is not None

        self.any_connected_this_frame    : bool = False
        self.any_disconnected_this_frame : bool = False

        for i in range(4):
            self._slots.append(GamepadSlot(i))
            self.gamepads.append(Gamepad(self._slots[i]))

    def update(self) -> None:
        """Call as part of your main loop, to poll for input."""
        if not self.supported:
            return
        self.any_connected_this_frame    = False
        self.any_disconnected_this_frame = False
        for i in range(4):
            slot  = self._slots[i]
            prior = slot.connected
            slot.update()

            if prior != slot.connected:
                if prior:
                    self.any_disconnected_this_frame = True
                else:
                    self.any_connected_this_frame = True

            buttons_mask = slot.current_state.gamepad.wButtons
            gamepad = self.gamepads[i]
            gamepad.stop_ignoring_buttons_by_mask(buttons_mask)

    def get_first_connected_gamepad(self) -> Optional[Gamepad]:
        if not self.supported:
            return None
        for gamepad in self.gamepads:
            if gamepad.connected:
                return gamepad
        return None

    def get_gamepad_if_connected(self, slot:int) -> Optional[Gamepad]:
        if not self.supported:
            return None
        gamepad = self.gamepads[slot]
        if gamepad is not None and gamepad.connected:
            return gamepad
        return None

MANAGER = _XInputManager()